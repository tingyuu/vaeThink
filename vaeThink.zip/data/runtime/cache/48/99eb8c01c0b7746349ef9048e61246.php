<?php
//000000000000
 exit();?>
a:1:{s:4:"hehe";s:16:"index/index/hehe";}