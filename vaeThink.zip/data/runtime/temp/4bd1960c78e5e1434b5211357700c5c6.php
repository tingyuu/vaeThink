<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:41:"themes/admin_themes/view/route\index.html";i:1537835771;}*/ ?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>vaeThink</title>
  <meta name="renderer" content="webkit">
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
  <link rel="stylesheet" href="/themes/admin_themes/lib/layui/css/layui.css"  media="all">
</head>
<body class="vae-body">

<div class="vae-content">
  <form class="layui-form" style="display: inline;">
    <input type="text" name="keywords" required  lay-verify="required" placeholder="ID/原始url/设置的url" class="layui-input" autocomplete="off" style="max-width: 200px;display: inline;margin: -10px 10px 0 0;height: 30px;" />
    <button class="layui-btn layui-btn-sm layui-btn-danger" lay-submit="" lay-filter="vaeform">提交搜索</button>
  </form> 
  <table class="layui-hide" id="test" lay-filter="test"></table>
</div>

<script type="text/html" id="status">
  <i class="layui-icon {{#  if(d.status == 1){ }}layui-icon-ok{{#  } else { }}layui-icon-close{{#  } }}"></i>
</script>
<script type="text/html" id="toolbarDemo">
  <div class="layui-btn-container">
    <button class="layui-btn layui-btn-primary layui-btn-sm" vaeyo_tab vae-id="1010" vae-title="添加路由" vae-src="/admin/route/add">添加路由</button>
  </div>
</script>
<script type="text/html" id="barDemo">
  <a class="layui-btn layui-btn-xs layui-btn-primary" vaeyo_tab vae-id="1011" vae-title="编辑路由" vae-src="/admin/route/edit/id/{{d.id}}">编辑</a>
  <a class="layui-btn layui-btn-danger layui-btn-xs" lay-event="del">删除</a>
</script>
              
          
<script src="/themes/admin_themes/lib/layui/layui.js" charset="utf-8"></script>
 
<script>
layui.config({
    base: '/themes/admin_themes/module/'
}).use(['table','vaeyo','form'], function(){
  var table = layui.table
  ,vae = layui.vaeyo
  ,$ = layui.$
  ,form = layui.form;
  
  var tableIns = table.render({
    elem: '#test'
    ,toolbar: '#toolbarDemo'
    ,title: '用户数据表'
    ,url: '/admin/route/getRouteList' //数据接口
    ,page: true //开启分页
    ,cols: [[ //表头
      {type: 'checkbox', fixed: 'left'}
      ,{field: 'id', title: 'ID', sort: true, fixed: 'left', align:'center', width:80}
      ,{field: 'full_url', title: '原始url', align:'center'}
      ,{field: 'url', title:'设置的rul', align:'center',}
      ,{field: 'status', title:'状态', toolbar: '#status', align:'center', width:100}
      ,{field: 'right', toolbar: '#barDemo', width:150, align:'center'}
    ]]
  });
  
  //监听行工具事件
  table.on('tool(test)', function(obj){
    var data = obj.data;
    //console.log(obj)
    if(obj.event === 'del'){
      layer.confirm('真的删除行么', {icon: 3, title:'提示'}, function(index){
        $.ajax({
          url:"/admin/route/delete",
          data:{id:data.id},
          success:function(res){
            layer.msg(res.msg);
            if(res.code==1){
              obj.del();
            }
          }
        })
        layer.close(index);
      });
    }
  });

  //监听搜索提交
  form.on('submit(vaeform)', function(data){
    console.log(data.field.keywords)
    if(data.field.keywords) {
      tableIns.reload({where:{keywords:data.field.keywords}});
    }
    return false;
  });
});
</script>

</body>
</html>