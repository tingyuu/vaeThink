<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:41:"themes/admin_themes/view/admin\index.html";i:1537835771;}*/ ?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>vaeThink</title>
  <meta name="renderer" content="webkit">
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
  <link rel="stylesheet" href="/themes/admin_themes/lib/layui/css/layui.css"  media="all">
</head>
<body class="vae-body">

<div class="vae-content">
  <form class="layui-form" style="display: inline;">
    <input type="text" name="keywords" required  lay-verify="required" placeholder="ID/用户名/昵称/电话/备注" class="layui-input" autocomplete="off" style="max-width: 200px;display: inline;margin: -10px 10px 0 0;height: 30px;" />
    <button class="layui-btn layui-btn-sm layui-btn-danger" lay-submit="" lay-filter="vaeform">提交搜索</button>
  </form> 
  <table class="layui-hide" id="test" lay-filter="test"></table>
</div>

<script type="text/html" id="thumb">
  <img src='{{d.thumb}}' height="25" style="border-radius: 50%;" />
</script>
<script type="text/html" id="status">
  <i class="layui-icon {{#  if(d.status == 1){ }}layui-icon-ok{{#  } else { }}layui-icon-close{{#  } }}"></i>
</script>
<script type="text/html" id="toolbarDemo">
  <div class="layui-btn-container">
    <button class="layui-btn layui-btn-primary layui-btn-sm" vaeyo_tab vae-id="1003" vae-title="添加管理员" vae-src="/admin/admin/add">添加管理员</button>
  </div>
</script>
<script type="text/html" id="barDemo">
  <a class="layui-btn layui-btn-xs layui-btn-primary" vaeyo_tab vae-id="1004" vae-title="编辑管理员" vae-src="/admin/admin/edit/id/{{d.id}}">编辑</a>
  <a class="layui-btn layui-btn-danger layui-btn-xs" lay-event="del">删除</a>
</script>
              
          
<script src="/themes/admin_themes/lib/layui/layui.js" charset="utf-8"></script>
 
<script>
layui.config({
    base: '/themes/admin_themes/module/'
}).use(['table','vaeyo','form'], function(){
  var table = layui.table
  ,vae = layui.vaeyo
  ,$ = layui.$
  ,form = layui.form;
  
  var tableIns = table.render({
    elem: '#test'
    ,toolbar: '#toolbarDemo'
    ,title: '用户数据表'
    ,url: '/admin/admin/getAdminList' //数据接口
    ,page: true //开启分页
    ,cols: [[ //表头
      {type: 'checkbox', fixed: 'left'}
      ,{field: 'id', title: 'ID', sort: true, fixed: 'left', align:'center', width:80}
      ,{field: 'groupName', title: '分组', align:'center'}
      ,{field: 'thumb', title:'头像', toolbar: '#thumb', align:'center', width:80}
      ,{field: 'username', title: '用户名', align:'center'}
      ,{field: 'nickname', title: '昵称', align:'center'}
      ,{field: 'phone', title: '手机', align:'center'} 
      ,{field: 'last_login_time', title: '最后登录时间', sort: true, align:'center', sort: true}
      ,{field: 'last_login_ip', title: '最后登录IP', align:'center'}
      ,{field: 'login_num', title: '累计登录', align:'center', sort: true, width:100}
      ,{field: 'status', title:'状态', toolbar: '#status', align:'center', width:100}
      ,{field: 'right', toolbar: '#barDemo', width:150, align:'center'}
    ]]
  });
  
  //监听行工具事件
  table.on('tool(test)', function(obj){
    var data = obj.data;
    //console.log(obj)
    if(obj.event === 'del'){
      layer.confirm('真的删除行么', {icon: 3, title:'提示'}, function(index){
        $.ajax({
          url:"/admin/admin/delete",
          data:{id:data.id},
          success:function(res){
            layer.msg(res.msg);
            if(res.code==1){
              obj.del();
            }
          }
        })
        layer.close(index);
      });
    }
  });

  //监听搜索提交
  form.on('submit(vaeform)', function(data){
    console.log(data.field.keywords)
    if(data.field.keywords) {
      tableIns.reload({where:{keywords:data.field.keywords}});
    }
    return false;
  });
});
</script>

</body>
</html>