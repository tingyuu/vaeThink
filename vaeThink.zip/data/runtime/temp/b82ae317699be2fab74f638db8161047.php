<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:40:"themes/admin_themes/view/group\edit.html";i:1537835771;}*/ ?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>vaeThink</title>
	<link rel="stylesheet" type="text/css" href="/themes/admin_themes/lib/layui/css/layui.css">
</head>
<body class="vae-body">

	<form class="layui-form vae-content">
		<div class="layui-form-item">
			<label class="layui-form-label">角色名称</label>
			<div class="layui-input-block" style="max-width: 500px;">
				<input class="layui-input" type="text" name="title" lay-verify="required" placeholder="请输入角色名称" autocomplete="off" value="<?php echo $group['title']; ?>" />
			</div>
		</div>
		<div class="layui-form-item">
			<label class="layui-form-label">选择权限</label>
			<div class="layui-input-block">
				<div id="vaeTree"></div>
			</div>
		</div>
		<div class="layui-form-item">
		    <label class="layui-form-label">状态</label>
		    <div class="layui-input-block">
		      <input type="radio" name="status" value="1" title="正常" <?php if($group['status'] == '1'): ?>checked<?php endif; ?>>
		      <input type="radio" name="status" value="-1" title="禁用" <?php if($group['status'] == '-1'): ?>checked<?php endif; ?>>
		    </div>
		 </div>
		<div class="layui-form-item layui-form-text">
		    <label class="layui-form-label">备注</label>
		    <div class="layui-input-block" style="max-width: 600px;">
		      <textarea name="desc" placeholder="请输入备注" class="layui-textarea"><?php echo $group['desc']; ?></textarea>
		    </div>
		</div>
		<div class="layui-form-item">
			<input type="hidden" name="id" value="<?php echo $group['id']; ?>" />
			<div class="layui-input-block">
				<button class="layui-btn" type="submit" lay-submit lay-filter="vaeform">提交</button>
				<button class="layui-btn layui-btn-primary" type="reset">重置</button>
			</div>
		</div>
	</form>

</body>
<script type="text/javascript" src="/themes/admin_themes/lib/layui/layui.js"></script>
<script type="text/javascript">
layui.config({
	base: '/themes/admin_themes/module/',
}).extend({
	authtree: 'authtree',
}).use(['jquery', 'authtree', 'form', 'layer', 'vaeyo'], function(){
	var $ = layui.jquery;
	var authtree = layui.authtree;
	var form = layui.form;
	var layer = layui.layer;
	var vae = layui.vaeyo;
	// 初始化
	$.ajax({
		url: "/admin/api/getRuleTree/id/<?php echo $id; ?>",
		dataType: 'json',
		success: function(data){
			authtree.render('#vaeTree', data.data.trees, {inputname: 'rules[]', layfilter: 'lay-check-auth', openall: false});
		}
	});

	//监听提交
	form.on('submit(vaeform)', function(obj){
		$.ajax({
			url: '/admin/group/editSubmit',
			data: obj.field,
			type: 'post',
			success: function(res){
				if(res.code==1){
		          layer.confirm('保存成功,关闭本页面吗?', {icon: 3, title:'提示'}, function(index){
		            vae.closeThisTab();
		            layer.close(index);
		          });
		        }else{
		          layer.msg(res.msg);
		        }
			}
		});
		return false;
	});

});
</script>
</html>