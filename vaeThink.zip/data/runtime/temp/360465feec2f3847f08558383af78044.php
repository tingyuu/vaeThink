<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:44:"themes/admin_themes/view/publicer\login.html";i:1537951200;}*/ ?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>vaeThink</title>
        <link rel="stylesheet" href="/themes/admin_themes/lib/layui/css/layui.css"  media="all">
        <style type="text/css">
            /*body{
                background:url('/themes/admin_themes/lib/vaeyo/img/bg.jpg');
            }*/
            .vaeyo-login-body{
                min-width:300px;
                max-width:400px;
                min-height:150px;
                margin:0 auto;
                margin-top:150px
            }
            .vaeyo-login-body h2{
                margin: 20px auto;
                text-align: center;
                font-size: 32px;
            }
        </style>
    </head>
    <body>
    	<div class="vaeyo-login-body">
            <h2>vaeThink</h2>
	        <form class="layui-form" id="vaeyo-login">
			  <div class="layui-form-item">
			      <input type="text" name="username" lay-verify="required" placeholder="账户" autocomplete="off" class="layui-input" value="vae">
			  </div>
			  <div class="layui-form-item">
			      <input type="password" name="password" lay-verify="required" placeholder="密码:vaethink" autocomplete="off" class="layui-input">
			  </div>
			  <div class="layui-form-item">
			      <div class="layui-input-inline">
			        <input type="text" name="captcha" placeholder="验证码" autocomplete="off" class="layui-input">
			      </div>
			      <div class="layui-input-inline">
			        <img src="/captcha" class="layadmin-user-login-codeimg" height="39" width="200" id="captcha" onclick="this.src='/captcha?seed='+Math.random()">
			      </div>
			  </div>
			  <button class="layui-btn layui-btn-fluid layui-bg-cyan" lay-submit lay-filter="vaeyo-login-submit" id="vaeyo-login-submit">登入系统</button>
			</form>
		</div>
		<script src="/themes/admin_themes/lib/layui/layui.js"></script>
		<script type="text/javascript">
			layui.use(['form'], function () {
		        var form = layui.form,$ = layui.$;
		        form.on('submit(vaeyo-login-submit)', function(data) {
                    $.ajax({
                        url:"/admin/publicer/loginSubmit",
                        data:$('#vaeyo-login').serialize(),
                        type:'post',
                        async: false,
                        success:function(res) {
                            layer.tips(res.msg,'#vaeyo-login-submit');
                            if(res.code === 1) {
                                setTimeout(function() {
                                    location.href = "/admin/index/index";
                                }, 1500);
                            } else {
                                $('#captcha').click();
                            }
                        }
                    })
                    return false;
                });
		    });
		</script>
    </body>
</html>