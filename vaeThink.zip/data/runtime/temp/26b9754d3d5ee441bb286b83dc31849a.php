<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:39:"themes/admin_themes/view/admin\add.html";i:1537835771;}*/ ?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>vaeThink</title>
  <meta name="renderer" content="webkit">
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
  <link rel="stylesheet" href="/themes/admin_themes/lib/layui/css/layui.css"  media="all">
</head>
<body class="vae-body">

<form class="layui-form vae-content">

  <div class="layui-form-item">
    <label class="layui-form-label">用户名</label>
    <div class="layui-input-block" style="max-width: 500px;">
      <input type="text" name="username" lay-verify="required" autocomplete="off" placeholder="请输入节点名称" class="layui-input">
    </div>
  </div>
  <div class="layui-form-item">
    <label class="layui-form-label">密码</label>
    <div class="layui-input-inline">
      <input type="password" name="password" lay-verify="required" placeholder="请输入密码" autocomplete="off" class="layui-input">
    </div>
    <label class="layui-form-label">确认密码</label>
    <div class="layui-input-inline">
      <input type="password" name="password_confirm" lay-verify="required" placeholder="请再次输入密码" autocomplete="off" class="layui-input">
    </div>
  </div>
  <div class="layui-form-item">
    <label class="layui-form-label">昵称</label>
    <div class="layui-input-inline">
      <input type="text" name="nickname" lay-verify="required" placeholder="请输入昵称" autocomplete="off" class="layui-input">
    </div>
    <label class="layui-form-label">手机</label>
    <div class="layui-input-inline">
      <input type="text" name="phone" lay-verify="required" placeholder="请输入手机" autocomplete="off" class="layui-input">
    </div>
  </div>
  <div class="layui-form-item">
    <label class="layui-form-label">头像</label>
    <div class="layui-input-inline">
      <div class="layui-upload">
        <button type="button" class="layui-btn" id="test1">上传头像</button>
        <div class="layui-upload-list" id="demo1">
          <img src="" />
          <input type="hidden" name="thumb" value="">
        </div>
      </div>
    </div>
  </div> 
  <div class="layui-form-item">
    <label class="layui-form-label">分组</label>
    <div class="layui-input-block">
      <?php $_result=vae_get_admin_group();if(is_array($_result) || $_result instanceof \think\Collection || $_result instanceof \think\Paginator): $i = 0; $__LIST__ = $_result;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$v): $mod = ($i % 2 );++$i;?>
      <input type="checkbox" name="group_id[]" title="<?php echo $v['title']; ?>" value="<?php echo $v['id']; ?>">
      <?php endforeach; endif; else: echo "" ;endif; ?>
    </div>
  </div>
  <div class="layui-form-item">
    <label class="layui-form-label">状态</label>
    <div class="layui-input-block">
      <input type="radio" name="status" value="1" title="正常" checked>
      <input type="radio" name="status" value="-1" title="禁止登录">
    </div>
  </div>
  <div class="layui-form-item layui-form-text">
    <label class="layui-form-label">备注</label>
    <div class="layui-input-block" style="max-width: 600px;">
      <textarea name="desc" placeholder="请输入备注" class="layui-textarea"></textarea>
    </div>
  </div>
  <div class="layui-form-item">
    <div class="layui-input-block">
      <button class="layui-btn" lay-submit="" lay-filter="vaeform">立即提交</button>
      <button type="reset" class="layui-btn layui-btn-primary">重置</button>
    </div>
  </div>
</form>
          
<script src="/themes/admin_themes/lib/layui/layui.js" charset="utf-8"></script>
<script>
layui.config({
    base: '/themes/admin_themes/module/'
}).use(['upload','form','vaeyo'], function(){
  var form = layui.form
  ,layer = layui.layer
  ,$ = layui.$
  ,upload = layui.upload
  ,vae = layui.vaeyo;

  //头像上传
  var uploadInst = upload.render({
    elem: '#test1'
    ,url: '/admin/api/upload'
    ,done: function(res){
      //如果上传失败
      if(res.code == 0){
        return layer.msg('上传失败');
      }
      //上传成功
      $('#demo1 input').attr('value',res.data);
      $('#demo1 img').attr('src',res.data);
    }
  });
  
  //监听提交
  form.on('submit(vaeform)', function(data){
    $.ajax({
      url:"/admin/admin/addSubmit",
      type:'post',
      data:data.field,
      success:function(e){
        if(e.code==1){
          layer.confirm('保存成功,关闭本页面吗?', {icon: 3, title:'提示'}, function(index){
            vae.closeThisTab();
            layer.close(index);
          });
        }else{
          layer.msg(e.msg);
        }
      }
    })
    return false;
  });
  
});
</script>

</body>
</html>