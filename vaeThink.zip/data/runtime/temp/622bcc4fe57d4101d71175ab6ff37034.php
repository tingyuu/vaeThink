<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:38:"themes/admin_themes/view/cate\add.html";i:1537835771;}*/ ?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>vaeThink</title>
  <meta name="renderer" content="webkit">
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
  <link rel="stylesheet" href="/themes/admin_themes/lib/layui/css/layui.css"  media="all">
</head>
<body class="vae-body">

<form class="layui-form vae-content">
  <div class="layui-form-item">
    <label class="layui-form-label">父级分类</label>
    <div class="layui-input-block">
      <select name="pid" lay-verify="required" lay-search="">
        <option value="0">作为顶级分类</option>
        <?php $_result=vae_set_recursion(vae_get_article_cate());if(is_array($_result) || $_result instanceof \think\Collection || $_result instanceof \think\Paginator): $i = 0; $__LIST__ = $_result;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$v): $mod = ($i % 2 );++$i;?>
        <option value="<?php echo $v['id']; ?>" <?php if($pid == $v['id']): ?>selected=""<?php endif; ?>><?php echo $v['title']; ?></option>
        <?php endforeach; endif; else: echo "" ;endif; ?>
      </select>
    </div>
  </div>

  <div class="layui-form-item">
    <label class="layui-form-label">名称</label>
    <div class="layui-input-block">
      <input type="text" name="title" lay-verify="required" autocomplete="off" placeholder="请输入名称" class="layui-input" style="max-width: 500px;">
    </div>
  </div>
  <div class="layui-form-item">
    <label class="layui-form-label">关键词</label>
    <div class="layui-input-block" style="max-width: 600px;">
      <input type="text" name="keywords" placeholder="请输入关键词，用“,”隔开，可空" autocomplete="off" class="layui-input">
    </div>
  </div>
  <div class="layui-form-item layui-form-text">
      <label class="layui-form-label">描述</label>
      <div class="layui-input-block" style="max-width: 600px;">
        <textarea name="desc" placeholder="请输入描述，可空" class="layui-textarea"></textarea>
      </div>
  </div>
  <div class="layui-form-item">
    <div class="layui-input-block">
      <button class="layui-btn" lay-submit="" lay-filter="vaeform">立即提交</button>
      <button type="reset" class="layui-btn layui-btn-primary">重置</button>
    </div>
  </div>
</form>
          
<script src="/themes/admin_themes/lib/layui/layui.js" charset="utf-8"></script>
<script>
layui.config({
    base: '/themes/admin_themes/module/'
}).use(['form','vaeyo'], function(){
  var form = layui.form
  ,layer = layui.layer
  ,$ = layui.$
  ,vae = layui.vaeyo;
  
  //监听提交
  form.on('submit(vaeform)', function(data){
    $.ajax({
      url:"/admin/cate/addSubmit",
      type:'post',
      data:data.field,
      success:function(e){
        if(e.code==1){
          layer.confirm('保存成功,关闭本页面吗?', {icon: 3, title:'提示'}, function(index){
            vae.closeThisTab();
            layer.close(index);
          });
        }else{
          layer.msg(e.msg);
        }
      }
    })
    return false;
  });
  
});
</script>

</body>
</html>