<?php
namespace app\admin\controller;
use vae\controller\AdminCheckLogin;

class Index extends AdminCheckLogin
{
    public function index()
    {
        return view();
    }
}
